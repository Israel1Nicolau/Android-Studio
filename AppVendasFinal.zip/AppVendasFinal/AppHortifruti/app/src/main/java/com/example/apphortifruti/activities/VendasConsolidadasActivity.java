package com.example.apphortifruti.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.apphortifruti.R;
import com.example.apphortifruti.adapters.AdapterListaDasVendas;
import com.example.apphortifruti.model.Venda;

import java.util.List;

import com.example.apphortifruti.controller.VendaCtrl;
import com.example.apphortifruti.dbHelper.ConexaoSQLite;

public class VendasConsolidadasActivity extends AppCompatActivity {

    private ListView lsvVendas;
    private List<Venda> listaDeVendasFeitas;
    private AdapterListaDasVendas adapterListaDasVendas;
    private VendaCtrl vendaCtrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendas_consolidadas);

        this.vendaCtrl = new VendaCtrl(ConexaoSQLite.getInstancia(VendasConsolidadasActivity.this));

        listaDeVendasFeitas = this.vendaCtrl.listarVendasCtrl();

        this.lsvVendas = (ListView) findViewById(R.id.lsvMinhasVendas);

        this.adapterListaDasVendas = new AdapterListaDasVendas(VendasConsolidadasActivity.this, listaDeVendasFeitas);

        this.lsvVendas.setAdapter(this.adapterListaDasVendas);

    }
}
