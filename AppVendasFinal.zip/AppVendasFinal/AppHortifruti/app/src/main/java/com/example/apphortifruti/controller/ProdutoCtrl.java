package com.example.apphortifruti.controller;

import com.example.apphortifruti.model.Produto;

import java.util.List;

import com.example.apphortifruti.DAO.ProdutoDAO;
import com.example.apphortifruti.dbHelper.ConexaoSQLite;

public class ProdutoCtrl {
    private final ProdutoDAO produtoDAO;

    public ProdutoCtrl(ConexaoSQLite pConexaoSQLite){
        produtoDAO = new ProdutoDAO(pConexaoSQLite);
    }
    public long salvarProdutoCtrl(Produto pProduto){
        return this.produtoDAO.salvarProdutoDAO(pProduto);
    }
    public List<Produto> getListaProdutosCtrl(){
        return this.produtoDAO.getListaProdutosDAO();
    }
    public boolean excluirProdutoCtrl(long pIdProduto){
        return this.produtoDAO.excluirProdutoDAO(pIdProduto);
    }

    public boolean atualizarProdutoCtrl(Produto pProduto){
        return this.produtoDAO.atualizarProdutoDAO(pProduto);
    }
}
