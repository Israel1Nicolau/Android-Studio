package com.example.apphortifruti.model;

import java.util.Date;
import java.util.List;

public class Venda {
    private long id;
    private Date dataDaVenda;
    private String nomeDoCliente; // implementar depois
    private List<ItemDoCarrinho> itensDaVenda;
    private double totalVenda;
    private int qteItens;

    // mesma coisa que fiz na classe Produtos
    public Venda() {
    }

    public int getQteItens() {
        return qteItens;
    }

    public void setQteItens(int qteItens) {
        this.qteItens = qteItens;
    }

    public long getId() { return id; }

    public void setId(long id) { this.id = id; }

    public double getTotalVenda() {
        return totalVenda;
    }

    public void setTotalVenda(double totalVenda) {
        this.totalVenda = totalVenda;
    }

    public List<ItemDoCarrinho> getItensDaVenda() {
        return itensDaVenda;
    }

    public void setItensDaVenda(List<ItemDoCarrinho> itensDaVenda) {
        this.itensDaVenda = itensDaVenda;
    }

    public Date getDataDaVenda() { return dataDaVenda; }

    public void setDataDaVenda(Date dataDaVenda) { this.dataDaVenda = dataDaVenda; }

    public String getNomeDoCliente() { return nomeDoCliente; }

    public void setNomeDoCliente(String nomeDoCliente) { this.nomeDoCliente = nomeDoCliente; }

    @Override
    public String toString() {
        return "Venda{" +
                "id=" + id +
                ", dataDaVenda=" + dataDaVenda +
                ", nomeDoCliente='" + nomeDoCliente + '\'' +
                '}';
    }
}
