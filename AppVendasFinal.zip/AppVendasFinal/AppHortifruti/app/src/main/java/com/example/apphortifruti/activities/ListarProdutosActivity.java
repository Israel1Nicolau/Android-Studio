package com.example.apphortifruti.activities;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.apphortifruti.R;
import com.example.apphortifruti.adapters.AdapterListaProdutos;
import com.example.apphortifruti.model.Produto;

import java.util.List;

import com.example.apphortifruti.controller.ProdutoCtrl;
import com.example.apphortifruti.dbHelper.ConexaoSQLite;

public class ListarProdutosActivity extends AppCompatActivity {

    private ListView lsvProdutos;
    private List<Produto> produtoList;
    private AdapterListaProdutos adapterListaProdutos;
    private ProdutoCtrl produtoCtrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_produtos);

        this.produtoCtrl = new ProdutoCtrl(ConexaoSQLite.getInstancia(ListarProdutosActivity.this));

        produtoList =  produtoCtrl.getListaProdutosCtrl();

        this.lsvProdutos = (ListView) findViewById(R.id.lsvProdutos);

        this.adapterListaProdutos = new AdapterListaProdutos(ListarProdutosActivity.this, this.produtoList);

        this.lsvProdutos.setAdapter(this.adapterListaProdutos);

        this.lsvProdutos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int posicao, long id) {
                final Produto produtoSelecionado = (Produto) adapterListaProdutos.getItem(posicao);
                AlertDialog.Builder janelaDeEscolha = new AlertDialog.Builder(ListarProdutosActivity.this);

                janelaDeEscolha.setTitle("Escolha:");
                janelaDeEscolha.setMessage("O que deseja fazer com o produto selecionado?");

                janelaDeEscolha.setNeutralButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int id) {
                        dialogInterface.cancel();
                    }
                });
                janelaDeEscolha.setNegativeButton("Excluir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int id) {

                        boolean excluiu = produtoCtrl.excluirProdutoCtrl(produtoSelecionado.getId());

                        dialogInterface.cancel();

                        if(excluiu == true){
                            adapterListaProdutos.removerProduto(posicao);
                            Toast.makeText(ListarProdutosActivity.this, "Produto Excluído com sucesso!", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(ListarProdutosActivity.this, "Erro ao excluir Produto!", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
                janelaDeEscolha.setPositiveButton("Editar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int id) {

                        Bundle bundleDadosProduto = new Bundle();

                        bundleDadosProduto.putLong("id_produto", produtoSelecionado.getId());
                        bundleDadosProduto.putString("nome_produto", produtoSelecionado.getNome());
                        bundleDadosProduto.putDouble("preco_produto", produtoSelecionado.getPreco());
                        bundleDadosProduto.putInt("estoque_produto", produtoSelecionado.getQuantidadeEmEstoque());

                        Intent intentEditarProdutos = new Intent(ListarProdutosActivity.this, EditarProdutosActivity.class);
                        intentEditarProdutos.putExtras(bundleDadosProduto);
                        startActivity(intentEditarProdutos);

                    }
                });

                janelaDeEscolha.create().show();

            }
        });
    }
    // executa evento de clique no botão atualizar
    public void eventAtualizarProdutos(View view){

        this.adapterListaProdutos.atualizar(this.produtoCtrl.getListaProdutosCtrl());

    }
}
