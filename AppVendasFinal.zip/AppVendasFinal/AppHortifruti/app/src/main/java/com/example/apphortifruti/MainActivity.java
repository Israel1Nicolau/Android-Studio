package com.example.apphortifruti;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.apphortifruti.activities.ActivityProduto;
import com.example.apphortifruti.activities.ActivityVenda;
import com.example.apphortifruti.activities.ListarProdutosActivity;
import com.example.apphortifruti.activities.VendasConsolidadasActivity;

import com.example.apphortifruti.dbHelper.ConexaoSQLite;

public class MainActivity extends AppCompatActivity {

    private Button btnCadastroProdutos;
    private Button btnListarProdutos;
    private Button btnVender;
    private Button btnMinhasVendas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ConexaoSQLite.getInstancia(this);

        this.btnCadastroProdutos = (Button) findViewById(R.id.btnCadastroProdutos);

        this.btnListarProdutos = (Button) findViewById(R.id.btnListarProdutos) ;

        this.btnVender = (Button) findViewById(R.id.btnVender);

        this.btnMinhasVendas = (Button) findViewById(R.id.btnMinhasVendas);

        this.btnCadastroProdutos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //executado ao clicar no botão
                Intent intent = new Intent(MainActivity.this, ActivityProduto.class);
                startActivity(intent);
            }
        });

        this.btnListarProdutos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListarProdutosActivity.class);
                startActivity(intent);
            }
        });

        this.btnVender.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                   Intent intent = new Intent(MainActivity.this, ActivityVenda.class);
                   startActivity(intent);
            }
        });

        this.btnMinhasVendas.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this, VendasConsolidadasActivity.class);
                startActivity(intent);
            }
        });
    }
}
