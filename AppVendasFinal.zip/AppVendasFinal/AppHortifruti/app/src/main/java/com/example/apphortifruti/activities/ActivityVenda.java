package com.example.apphortifruti.activities;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.apphortifruti.R;
import com.example.apphortifruti.adapters.AdapterItensDoCarrinho;
import com.example.apphortifruti.model.ItemDoCarrinho;
import com.example.apphortifruti.model.Produto;
import com.example.apphortifruti.model.Venda;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.example.apphortifruti.controller.ProdutoCtrl;
import com.example.apphortifruti.controller.VendaCtrl;
import com.example.apphortifruti.dbHelper.ConexaoSQLite;

public class ActivityVenda extends AppCompatActivity {

    private Spinner spnProdutos;
    private List<Produto> listaProduto;
    private ProdutoCtrl produtoCtrl;
    private EditText quantidadeItem;
    private TextView tvTotalVenda;

    //carrinho de compras
    private ListView lsvCarrinhoCompras;
    private List<ItemDoCarrinho> listaItensDoCarrinho;
    private AdapterItensDoCarrinho adpItemDoCarrinho;

    //controllers da venda
    private VendaCtrl vendaCtrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_venda);

        this.vendaCtrl = new VendaCtrl(ConexaoSQLite.getInstancia(this));

        //Spinner
        this.produtoCtrl = new ProdutoCtrl(ConexaoSQLite.getInstancia(this));
        this.listaProduto = this.produtoCtrl.getListaProdutosCtrl();

        this.spnProdutos = (Spinner) this.findViewById(R.id.spnProduto);
        ArrayAdapter<Produto> spnProdutoAdapter = new ArrayAdapter<Produto>(
                this,
                android.R.layout.simple_spinner_item,
                this.listaProduto
        );

        this.spnProdutos.setAdapter(spnProdutoAdapter);
        //endSpinner
        this.quantidadeItem = (EditText) this.findViewById(R.id.edtQuantidadeProduto);

        this.tvTotalVenda = (TextView) this.findViewById(R.id.tvTotalVenda);

        //variaveis e objetos do carrinho
        this.lsvCarrinhoCompras = (ListView) this.findViewById(R.id.lsvProdutos);
        this.listaItensDoCarrinho = new ArrayList<>();
        this.adpItemDoCarrinho = new AdapterItensDoCarrinho(ActivityVenda.this, this.listaItensDoCarrinho);
        this.lsvCarrinhoCompras.setAdapter(this.adpItemDoCarrinho);

        this.lsvCarrinhoCompras.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int posicao, long id) {

                final ItemDoCarrinho itemDoCarrinho = (ItemDoCarrinho) adpItemDoCarrinho.getItem(posicao);

                AlertDialog.Builder janelaDaEscolha = new AlertDialog.Builder(ActivityVenda.this);
                janelaDaEscolha.setTitle("Escolha:");
                janelaDaEscolha.setMessage("Deseja remover o item " + itemDoCarrinho.getNome() + " ?");

                janelaDaEscolha.setNegativeButton("Não", null);
                janelaDaEscolha.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        boolean excluiu = false;

                        excluiu = adpItemDoCarrinho.removerItemDoCarrinho(posicao);

                        double totalVenda = calcularTotalVenda(listaItensDoCarrinho);
                        atualizarValorTotalVenda(totalVenda);

                        if(!excluiu){
                            Toast.makeText(ActivityVenda.this, "Erro ao exclur item do carrinho", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                janelaDaEscolha.create().show();

            }
        });
    }

    /**
     * Clique no botão de finalizar venda
     * @param view
     */
    public void eventFecharVenda(View view){
       Venda vendaFechada = this.criarVenda();

       if(this.salvarVenda(vendaFechada) == true){
           Toast.makeText(this, "Venda concluída com sucesso!", Toast.LENGTH_SHORT).show();
       }else{
           Toast.makeText(this, "Erro ao concluir a venda!", Toast.LENGTH_SHORT).show();
       }
    }

    /**
     * Clique no botão de adicionar ao carrinho
     * @param view
     */
    public void eventAddProduto(View view){

        ItemDoCarrinho itemDoCarrinho = new ItemDoCarrinho();

        Produto produtoSelecionado = (Produto) this.spnProdutos.getSelectedItem();

        int quantidadeProduto = 0;

        if(this.quantidadeItem.getText().toString().equals("")){
            quantidadeProduto = 1;
        }else{
            quantidadeProduto = Integer.parseInt(this.quantidadeItem.getText().toString());
        }

        itemDoCarrinho.setNome(produtoSelecionado.getNome());
        itemDoCarrinho.setIdProduto(produtoSelecionado.getId());
        itemDoCarrinho.setQuantidadeSelecionada(quantidadeProduto);
        itemDoCarrinho.setPrecoProduto(produtoSelecionado.getPreco());
        itemDoCarrinho.setPrecoDoItemDaVenda(itemDoCarrinho.getPrecoProduto() * itemDoCarrinho.getQuantidadeSelecionada());

        this.adpItemDoCarrinho.addItemDoCarrinho(itemDoCarrinho);

        double totalVenda = this.calcularTotalVenda(this.listaItensDoCarrinho);
        this.atualizarValorTotalVenda(totalVenda);
    }

    private double calcularTotalVenda(List<ItemDoCarrinho> pListaItensDoCarrinho){

        double totalVenda = 0.0d;

        for(ItemDoCarrinho itemDoCarrinho : pListaItensDoCarrinho){
            totalVenda += itemDoCarrinho.getPrecoDoItemDaVenda();
        }

        return totalVenda;
    }

    private void atualizarValorTotalVenda(double pValorTotal){
        this.tvTotalVenda.setText(String.valueOf(pValorTotal));
    }

    private Venda criarVenda(){
        Venda venda = new Venda();
        venda.setDataDaVenda(new Date());
        venda.setItensDaVenda(this.listaItensDoCarrinho);

        return venda;
    }

    private boolean salvarVenda(Venda pVenda){

        long idVenda = vendaCtrl.salvarVendaCtrl(pVenda);

        if(idVenda > 0){

            pVenda.setId(idVenda);

            if(vendaCtrl.salvarItensVendaCtrl(pVenda)){
                Toast.makeText(this, "Venda Realizada!", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(this, "Tente Novamente, venda não concluída", Toast.LENGTH_SHORT).show();
            }

            return true;
        }

        return false;
    }

}
