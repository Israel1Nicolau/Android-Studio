package com.example.apphortidelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText cpfUsuario;
    private EditText senhaUsuario;

    private Button fazerLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.cpfUsuario = (EditText) findViewById(R.id.cpfUsuario);
        this.senhaUsuario = (EditText) findViewById(R.id.senhaUsuario);

        this.fazerLogin = (Button) findViewById(R.id.fazerLogin);

        fazerLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cpfUsuario.getText().length() == 0 || senhaUsuario.getText().length() == 0){
                    Toast.makeText(MainActivity.this, "Preencha todos os campos", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(MainActivity.this, "Bem vindo!!", Toast.LENGTH_SHORT).show();

                    fazerLogin.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(MainActivity.this, ListarProdutosActivity.class);
                            startActivity(intent);
                        }
                    });
                }
            }
        });

    }
    public void irParaTelaCadastro (View v){
        Intent intent = new Intent(MainActivity.this, CadastroUsuarioActivity.class);
        startActivity(intent);
    }

}
