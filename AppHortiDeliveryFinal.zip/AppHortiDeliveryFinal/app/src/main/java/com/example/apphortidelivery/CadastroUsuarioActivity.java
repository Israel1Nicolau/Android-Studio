package com.example.apphortidelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastroUsuarioActivity extends AppCompatActivity {

    private EditText nomeCadastro;
    private EditText cpfCadastro;
    private EditText cepCadastro;
    private EditText enderecoCadastro;
    private EditText numeroCasaCadastro;
    private EditText cidadeCadastro;
    private EditText estadoCadastro;
    private EditText emailCadastro;
    private EditText senhaCadastro;

    private Button cadastroFeito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_usuario);

        this.nomeCadastro = (EditText) findViewById(R.id.nomeCadastro);
        this.cpfCadastro = (EditText) findViewById(R.id.cpfCadastro);
        this.cepCadastro = (EditText) findViewById(R.id.cepCadastro);
        this.enderecoCadastro = (EditText) findViewById(R.id.enderecoCadastro);
        this.numeroCasaCadastro = (EditText) findViewById(R.id.numeroCasaCadastro);
        this.cidadeCadastro = (EditText) findViewById(R.id.cidadeCadastro);
        this.estadoCadastro = (EditText) findViewById(R.id.estadoCadastro);
        this.emailCadastro = (EditText) findViewById(R.id.emailCadastro);
        this.senhaCadastro = (EditText) findViewById(R.id.senhaCadastro);

        this.cadastroFeito = (Button) findViewById(R.id.cadastroFeito);

        cadastroFeito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nomeCadastro.getText().length() == 0 || cpfCadastro.getText().length() == 0){
                    Toast.makeText(CadastroUsuarioActivity.this, "Preencha todos os campos", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(CadastroUsuarioActivity.this, "Cadastrado com sucesso!!", Toast.LENGTH_LONG).show();

                    cadastroFeito.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(CadastroUsuarioActivity.this, MainActivity.class);
                            startActivity(intent);
                        }
                    });
                }
            }
        });

    }
}
